import {Injectable} from '@angular/core';

import {bindNodeCallback, defer, Observable, Subject} from 'rxjs';
import {map} from 'rxjs/operators';

import isEqualWith from 'lodash.isequalwith';

import Web3 from 'web3';
import * as Web3Types from 'web3/types';
import {default as contract} from 'truffle-contract';

import {NGXLogger} from 'ngx-logger';
import {Provider} from 'web3/types';

@Injectable({
  providedIn: 'root'
})
export class Web3Service
{
  private accountsObservable: Observable<string[]>;

  private web3: Web3;

  constructor(private logger: NGXLogger)
  {
    this.accountsObservable =
      defer(
        bindNodeCallback(this.web3.eth.getAccounts)
      )
        .pipe(
          map(
            (accs: string | string[]): string[] => {
              if (typeof accs === 'string') {
                accs = [accs];
              } else if (!accs || (
                accs.length === 0
              ))
              {
                this.logger.error(`Couldn't get any accounts!  Verify that your Ethereum client (MetaMask) is configured correctly.`, accs);
                accs = [];
              }

              return accs;
            }
          )
        );
  }

  public injectWeb3Adapter(web3Inst: Web3)
  {
    this.web3 = web3Inst;
  }

  public initTruffleContract<T extends {setProvider(provider: Provider): void; }>(json_artifact: object): T // Web3Types.Contract
  {
    this.assertWeb3Injection();

    // this.logger.info('Contract setup requested for', json_artifact);
    const retVal: T = contract(json_artifact) as T;
    retVal.setProvider(this.web3.currentProvider);
    this.logger.info('Returning contract:', retVal);

    return retVal;
  }

  public pollClaimedAccounts(): Observable<string[]>
  {
    this.assertWeb3Injection();

    return this.accountsObservable;
  }

  private assertWeb3Injection(): void
  {
    if (!this.web3) {
      throw new Error('Web3 dependency must be injected by an APP_INITIALIZER before calling this method');
    }
  }
}
