export * from './config-class.decorator';
export * from './config-prop.decorator';
