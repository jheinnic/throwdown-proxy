export const DI_TYPES = {
   ModuleRegistry: Symbol.for("ModuleRegistry"),
   ContainerModule: Symbol.for("ContainerModule"),
   Application: Symbol.for("Application"),
   ConfigLoader: Symbol.for("ConfigLoader")
}