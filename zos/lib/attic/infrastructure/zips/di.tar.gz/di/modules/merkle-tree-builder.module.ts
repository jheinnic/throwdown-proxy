// import {diModule} from '../decorators/di-module.decorator';
// import {MODULES} from './modules';
import {AbstractDIModule} from '../v1/abstract-di-module.class';
import {ArgsAsTuple} from 'simplytyped';

// @diModule(MODULES.MerkleTreeBuilder)
export class MerkleTreeBuilderModule extends AbstractDIModule {

}

