export interface IConfigLoader {

}