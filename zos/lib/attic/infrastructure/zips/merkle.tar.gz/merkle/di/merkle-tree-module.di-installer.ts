export function merkleTreeModuleDiInstaller() {

}