export enum MerkleOrientationType {
   LEFT_CHILD = "LeftChild",
   RIGHT_CHILD = "RightChild",
   ROOT = "Root"
}