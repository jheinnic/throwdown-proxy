export enum MerkleNodeType {
   LEAF,
   INTERNAL,
   ROOT
}