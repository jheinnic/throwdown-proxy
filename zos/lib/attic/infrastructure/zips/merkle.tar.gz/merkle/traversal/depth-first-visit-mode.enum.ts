export enum DepthFirstVisitMode {
   PRE_ORDER = 'PreOrder',
   IN_ORDER = 'InOrder',
   POST_ORDER = 'PostOrder'
};