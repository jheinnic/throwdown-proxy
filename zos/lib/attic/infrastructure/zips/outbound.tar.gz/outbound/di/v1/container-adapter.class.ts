import {Container} from 'inversify';

export class ContainerAdapter {
   private moduleContainer: Container;
   private appContainer: Container;

   constructor() {

   }
}