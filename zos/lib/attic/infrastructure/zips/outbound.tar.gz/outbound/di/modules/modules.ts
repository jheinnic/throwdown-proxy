export const MODULES = {
   MerkleTreeBuilder: Symbol.for("MerkleTreeBuilder"),
   MerkleFileStore: Symbol.for("MerkleFileStore"),
   BatchJobApp: Symbol.for("BatchJobApp"),
   SeedProofPoolBatchJob: Symbol.for("SeedProofPoolBatchJob")
};
